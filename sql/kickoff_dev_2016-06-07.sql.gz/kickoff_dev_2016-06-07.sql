# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.01 (MySQL 5.5.42)
# Database: kickoff_dev
# Generation Time: 2016-06-07 07:37:44 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table locations
# ------------------------------------------------------------

DROP TABLE IF EXISTS `locations`;

CREATE TABLE `locations` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `lat` float DEFAULT NULL,
  `long` float DEFAULT NULL,
  `postcode` varchar(8) DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;

INSERT INTO `locations` (`id`, `name`, `city`, `lat`, `long`, `postcode`, `updated`)
VALUES
	(8,'Anfield','Liverpool',53.4308,2.96083,NULL,NULL),
	(9,'Ayresome Park','Middlesbrough',54.5642,1.24694,NULL,NULL),
	(10,'Baseball Ground','Derby',52.9047,1.46861,NULL,NULL),
	(11,'Bloomfield Road','Blackpool',53.8047,3.04806,NULL,NULL),
	(12,'Upton Park','London',51.5319,0.0394444,'','2016-05-23 06:51:08'),
	(13,'Boundary Park','Oldham',53.5553,2.12861,NULL,NULL),
	(14,'Bramall Lane','Sheffield',53.3703,1.47083,NULL,NULL),
	(15,'Britannia Stadium','Stoke-on-Trent',52.9883,2.17556,NULL,NULL),
	(16,'Burnden Park','Bolton',53.5689,2.41611,NULL,NULL),
	(17,'Cardiff City Stadium','Cardiff',51.4728,3.20306,NULL,NULL),
	(18,'Carrow Road','Norwich',52.6222,1.30917,NULL,NULL),
	(19,'City Ground','Nottingham',52.94,1.13278,NULL,NULL),
	(20,'Etihad Stadium','Manchester',53.4831,2.20028,NULL,NULL),
	(21,'County Ground','Swindon',51.5644,1.77056,NULL,NULL),
	(22,'Craven Cottage','London',51.475,0.221667,NULL,NULL),
	(23,'Dean Court','Bournemouth',50.7353,1.83833,NULL,NULL),
	(24,'The Dell','Southampton',50.9147,1.41306,NULL,NULL),
	(25,'DW Stadium','Wigan',53.5475,2.65417,NULL,NULL),
	(26,'Elland Road','Leeds',53.7778,1.57222,NULL,NULL),
	(27,'Emirates Stadium','London',51.555,0.108611,NULL,NULL),
	(28,'Ewood Park','Blackburn',53.7286,2.48917,NULL,NULL),
	(29,'Filbert Street','Leicester',52.6236,1.14056,NULL,NULL),
	(30,'Fratton Park','Portsmouth',50.7964,1.06389,NULL,NULL),
	(31,'Goodison Park','Liverpool',53.4389,2.96639,NULL,NULL),
	(32,'The Hawthorns','West Bromwich',52.5092,1.96389,NULL,NULL),
	(33,'Highbury','London',51.5578,0.102778,NULL,NULL),
	(34,'Highfield Road','Coventry',52.4119,1.49,NULL,NULL),
	(35,'Hillsborough Stadium','Sheffield',53.4114,1.50056,NULL,NULL),
	(36,'KC Stadium','Kingston upon Hull',53.7461,0.3675,NULL,NULL),
	(37,'King Power Stadium','Leicester',52.6203,1.14222,NULL,NULL),
	(38,'Liberty Stadium','Swansea',51.6428,3.93472,NULL,NULL),
	(39,'Loftus Road','London',51.5092,0.232222,NULL,NULL),
	(40,'Macron Stadium','Bolton',53.5806,2.53556,NULL,NULL),
	(41,'Madejski Stadium','Reading',51.4222,0.982778,NULL,NULL),
	(42,'Maine Road','Manchester',53.4511,2.23528,NULL,NULL),
	(43,'Molineux Stadium','Wolverhampton',52.5903,2.13028,NULL,NULL),
	(44,'Oakwell','Barnsley',53.5522,1.4675,NULL,NULL),
	(45,'Old Trafford','Trafford',53.4631,2.29139,NULL,NULL),
	(46,'Portman Road','Ipswich',52.055,1.14472,NULL,NULL),
	(47,'Pride Park Stadium','Derby',52.915,1.44722,NULL,NULL),
	(48,'Riverside Stadium','Middlesbrough',54.5783,1.21694,NULL,NULL),
	(49,'Roker Park','Sunderland',54.9214,1.37556,NULL,NULL),
	(50,'St Andrew\'s','Birmingham',52.4758,1.86806,NULL,NULL),
	(51,'St. James\' Park','Newcastle upon Tyne',54.9756,1.62167,NULL,NULL),
	(52,'St Mary\'s Stadium','Southampton',50.9058,1.39111,NULL,NULL),
	(53,'Selhurst Park','London',51.3983,0.0855556,NULL,NULL),
	(54,'Stadium of Light','Sunderland',54.9144,1.38833,NULL,NULL),
	(55,'Stamford Bridge','London',51.4817,0.191111,NULL,NULL),
	(56,'Turf Moor','Burnley',53.7892,2.23028,NULL,NULL),
	(57,'The Valley','London',51.4864,0.0363889,NULL,NULL),
	(58,'Valley Parade','Bradford',53.8042,1.75889,NULL,NULL),
	(59,'Vicarage Road','Watford',51.65,0.401667,NULL,NULL),
	(60,'Villa Park','Birmingham',52.5092,1.88472,NULL,NULL),
	(61,'White Hart Lane','London',51.6033,0.0658333,NULL,NULL),
	(62,'Queen Elizabeth Olympic Park','London',51.5386,-0.0865645,'E20 2ST','2016-05-31 19:21:05'),
	(63,'Griffin Park','London',51.4882,-0.372564,'TW8 0NT','2016-05-31 19:23:54'),
	(64,'American Express Community Stadium','Brighton',50.8615,-0.153756,'BN1 9BL','2016-05-31 19:26:42'),
	(65,'Ashton Gate Stadium','Bristol',51.44,-2.69032,'BS3 2EJ','2016-05-31 20:10:52'),
	(66,'John Smith Stadium','Huddersfield',53.6542,-1.76845,'HD1 6PX','2016-05-31 20:18:03'),
	(67,'Stadium mk','Milton Keynes',52.0098,-0.804629,'MK1 1ST','2016-05-31 20:23:09'),
	(68,'Deepdale','Preston',53.7722,-2.75842,'PR1 6RU','2016-05-31 20:27:06'),
	(69,'New York Stadium','Rotherham',53.427,-1.43304,'S60 1AH','2016-05-31 20:30:09');

/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table teams
# ------------------------------------------------------------

DROP TABLE IF EXISTS `teams`;

CREATE TABLE `teams` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `short` varchar(10) DEFAULT NULL,
  `aliases` varchar(255) DEFAULT NULL,
  `slug` varchar(40) DEFAULT NULL,
  `competition_id` int(11) DEFAULT NULL,
  `sport_id` int(11) DEFAULT NULL,
  `theme_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `events_import_url` varchar(255) DEFAULT NULL,
  `events_import_updated` datetime DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `twitter` varchar(15) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;

INSERT INTO `teams` (`id`, `name`, `short`, `aliases`, `slug`, `competition_id`, `sport_id`, `theme_id`, `created`, `events_import_url`, `events_import_updated`, `location_id`, `twitter`, `website`)
VALUES
	(2,'England',NULL,NULL,'england',NULL,2,NULL,'2014-03-06 10:36:47',NULL,NULL,NULL,NULL,NULL),
	(3,'Oceania 1',NULL,NULL,'oceania-1',NULL,2,NULL,'2014-03-06 10:37:02',NULL,NULL,NULL,NULL,NULL),
	(4,'Wales',NULL,NULL,'wales',NULL,2,22,'2014-03-06 10:37:17',NULL,NULL,NULL,NULL,NULL),
	(5,'Australia',NULL,NULL,'australia',NULL,2,NULL,'2014-03-06 10:37:57',NULL,NULL,NULL,NULL,NULL),
	(69,'Derby County','DER','Derby, Rams','derby-county',1,1,30,'2014-03-06 18:22:51','http://www.bbc.co.uk/sport/football/teams/derby-county/fixtures','2016-02-02 11:38:00',47,'dcfcofficial','http://www.dcfc.co.uk/'),
	(70,'Doncaster Rovers','DON',NULL,'doncaster-rovers',NULL,1,NULL,'2014-03-06 18:22:51',NULL,NULL,NULL,NULL,NULL),
	(71,'Brighton & Hove Albion','BRI','Brighton','brighton-hove-albion',1,1,NULL,'2014-03-06 18:22:51','http://www.bbc.co.uk/sport/football/teams/brighton-and-hove-albion/fixtures','2015-07-28 20:00:00',64,'officialbhafc','http://www.seagulls.co.uk/'),
	(74,'Barnsley','BAR',NULL,'barnsley',NULL,1,NULL,'2014-03-06 18:22:51',NULL,NULL,NULL,NULL,NULL),
	(75,'Leeds United','LEE','Leeds','leeds-united',1,1,NULL,'2014-03-06 18:22:51','http://www.bbc.co.uk/sport/football/teams/leeds-united/fixtures','2015-07-28 20:01:00',26,'LUFC','http://www.leedsunited.com/'),
	(76,'Watford','WAT','Hornets','watford',20,1,57,'2014-03-06 18:22:51','http://www.bbc.co.uk/sport/football/teams/watford/fixtures',NULL,59,'WatfordFC','http://www.watfordfc.com/'),
	(78,'Leicester City','LEI','Leicester, Foxes','leicester-city',20,1,42,'2014-03-06 18:22:51','http://www.bbc.co.uk/sport/football/teams/leicester-city/fixtures','2015-07-28 20:01:00',37,'LCFC','http://www.lcfc.com/'),
	(82,'Wolverhampton Wanderers','WLV','Wolves','wolverhampton-wanderers',1,1,NULL,'2014-03-06 18:22:51','http://www.bbc.co.uk/sport/football/teams/wolverhampton-wanderers/fixtures','2015-07-28 20:02:00',43,'officialwolves','http://www.wolves.co.uk/'),
	(85,'Burnley','BUR','','burnley',1,1,NULL,'2014-03-06 18:22:51','http://www.bbc.co.uk/sport/football/teams/burnley/fixtures','2015-07-28 15:54:00',56,'BurnleyOfficial','http://www.burnleyfootballclub.com/'),
	(88,'Ipswich Town','IPS','Ipswich','ipswich-town',NULL,1,NULL,'2014-03-06 18:22:51','http://www.bbc.co.uk/sport/football/teams/ipswich-town/fixtures','2015-07-28 20:01:00',NULL,NULL,NULL),
	(91,'Huddersfield Town','HUD','Huddersfield, Terriers','huddersfield-town',1,1,NULL,'2014-03-06 18:22:51','http://www.bbc.co.uk/sport/football/teams/huddersfield-town/fixtures','2015-07-28 20:00:00',66,'htafcdotcom','http://www.htafc.com/'),
	(93,'Blackpool','BLK',NULL,'blackpool',NULL,1,NULL,'2014-03-06 18:22:51',NULL,NULL,NULL,NULL,NULL),
	(94,'Bradford','BRD',NULL,'bradford',NULL,1,NULL,'2014-03-06 18:22:51',NULL,NULL,NULL,NULL,NULL),
	(96,'Aston Villa','AST','Villa','aston-villa',20,1,36,'2014-03-06 18:22:51','http://www.bbc.co.uk/sport/football/teams/aston-villa/fixtures','2015-07-28 19:59:00',60,'AVFCOfficial','http://www.avfc.co.uk/'),
	(100,'Grange Park Rangers Red',NULL,NULL,'grange-park-rangers-red',NULL,1,NULL,'2014-03-06 18:22:51',NULL,NULL,NULL,NULL,NULL),
	(101,'Delapre Dragons',NULL,NULL,'delapre-dragons',NULL,1,NULL,'2014-03-06 18:22:51',NULL,NULL,NULL,NULL,NULL),
	(102,'Grange Park Rangers Blue',NULL,NULL,'grange-park-rangers-blue',NULL,1,NULL,'2014-03-06 18:22:51',NULL,NULL,NULL,NULL,NULL),
	(104,'Brazil',NULL,NULL,'brazil',NULL,1,NULL,'2014-03-06 18:22:51',NULL,NULL,NULL,NULL,NULL),
	(105,'Mexico',NULL,NULL,'mexico',NULL,1,NULL,'2014-03-06 18:22:51',NULL,NULL,NULL,NULL,NULL),
	(106,'Spain',NULL,NULL,'spain',NULL,1,NULL,'2014-03-06 18:22:51',NULL,NULL,NULL,NULL,NULL),
	(107,'Chile',NULL,NULL,'chile',NULL,1,NULL,'2014-03-06 18:22:51',NULL,NULL,NULL,NULL,NULL),
	(132,'Nottingham Forest','NTF','Nottm Forest, Forest','nottingham-forest',1,1,NULL,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/nottingham-forest/fixtures','2015-07-28 19:58:00',19,'Official_NFFC','http://www.nottinghamforest.co.uk/'),
	(134,'Crystal Palace','CRP','','crystal-palace',20,1,NULL,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/crystal-palace/fixtures','2015-07-28 15:47:00',53,'CPFC','http://www.cpfc.co.uk/'),
	(136,'Peterborough','PET',NULL,'peterborough',NULL,1,NULL,'2014-03-06 18:23:01',NULL,NULL,NULL,NULL,NULL),
	(137,'Bristol City','BRC','Robins','bristol-city',1,1,NULL,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/bristol-city/fixtures','2015-07-28 20:01:00',65,'bcfctweets','http://www.bcfc.co.uk/'),
	(140,'Hull City','HUL','Hull','hull-city',NULL,1,NULL,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/hull-city/fixtures','2015-07-28 20:01:00',NULL,NULL,NULL),
	(143,'Blackburn Rovers','BLK','Blackburn','blackburn-rovers',1,1,NULL,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/blackburn-rovers/fixtures','2015-07-28 19:59:00',28,'onerovers','http://www.rovers.co.uk/'),
	(144,'Brighton & Hove Albion','BHV','Brighton','brighton-hove-albion',1,1,NULL,'2014-03-06 18:23:01','',NULL,NULL,NULL,NULL),
	(148,'Cardiff City','CDF','Cardiff','cardiff-city',NULL,1,NULL,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/cardiff-city/fixtures','2015-07-28 19:59:00',NULL,NULL,NULL),
	(150,'Middlesbrough','MID','','middlesbrough',1,1,NULL,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/middlesbrough/fixtures','2015-07-28 19:59:00',48,'Boro','http://www.mfc.co.uk/'),
	(151,'Birmingham City','BIR','Birmingham','birmingham-city',1,1,NULL,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/birmingham-city/fixtures','2015-07-28 19:58:00',50,'BCFC','http://www.bcfc.com/'),
	(154,'Charlton Athletic','CHA','Charlton','charlton-athletic',1,1,NULL,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/charlton-athletic/fixtures',NULL,57,'CAFCofficial','http://www.cafc.co.uk/'),
	(156,'Sheffield Wednesday','SHW','Sheff Wed, Sheffield Wed, Wednesday, Owls','sheffield-wednesday',1,1,NULL,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/sheffield-wednesday/fixtures','2015-07-28 19:57:00',35,'swfc','http://www.swfc.co.uk/'),
	(157,'Scunthorpe','SCU',NULL,'scunthorpe',NULL,1,NULL,'2014-03-06 18:23:01',NULL,NULL,NULL,NULL,NULL),
	(158,'Millwall','MIL',NULL,'millwall',NULL,1,NULL,'2014-03-06 18:23:01',NULL,NULL,NULL,NULL,NULL),
	(160,'Swansea City','SWC','Swansea','swansea-city',20,1,51,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/swansea-city/fixtures','2015-07-28 19:51:00',38,'SwansOfficial','http://www.swanseacity.net/'),
	(162,'Chelsea','CHE','','chelsea',20,1,38,'2014-03-06 18:23:01','http://www.bbc.co.uk/sport/football/teams/chelsea/fixtures','2015-07-28 15:57:00',55,'ChelseaFC','https://www.chelseafc.com/'),
	(164,'Welland Valley Yellow',NULL,NULL,'welland-valley-yellow',NULL,1,NULL,'2014-03-06 18:23:01',NULL,NULL,NULL,NULL,NULL),
	(165,'Crick Colts U9','CC9','','crick-colts-u9',12,1,NULL,'2014-03-06 18:23:01','',NULL,NULL,NULL,NULL),
	(166,'Daventry Town','DAV',NULL,'daventry-town',NULL,1,NULL,'2014-03-06 18:23:01',NULL,NULL,NULL,NULL,NULL),
	(167,'West Haddon JFC',NULL,NULL,'west-haddon-jfc',NULL,1,NULL,'2014-03-06 18:23:01',NULL,NULL,NULL,NULL,NULL),
	(168,'Croatia',NULL,NULL,'croatia',NULL,1,NULL,'2014-03-06 18:23:01',NULL,NULL,NULL,NULL,NULL),
	(169,'Cameroon',NULL,NULL,'cameroon',NULL,1,NULL,'2014-03-06 18:23:01',NULL,NULL,NULL,NULL,NULL),
	(170,'Netherlands',NULL,NULL,'netherlands',NULL,1,NULL,'2014-03-06 18:23:01',NULL,NULL,NULL,NULL,NULL),
	(171,'Australia',NULL,NULL,'australia',NULL,1,NULL,'2014-03-06 18:23:01',NULL,NULL,NULL,NULL,NULL),
	(202,'FFA Black',NULL,NULL,'ffa-black',NULL,1,NULL,'2014-03-06 19:08:30',NULL,NULL,NULL,NULL,NULL),
	(203,'Towcester Town Green',NULL,NULL,'towcester-town-green',NULL,1,NULL,'2014-03-06 19:12:52',NULL,NULL,NULL,NULL,NULL),
	(204,'Hackleton Harriers',NULL,NULL,'hackleton-harriers',NULL,1,NULL,'2014-03-06 19:14:43',NULL,NULL,NULL,NULL,NULL),
	(205,'Towcester Town White',NULL,NULL,'towcester-town-white',NULL,1,NULL,'2014-03-06 19:16:15',NULL,NULL,NULL,NULL,NULL),
	(206,'Billing United',NULL,NULL,'billing-united',NULL,1,NULL,'2014-03-22 12:39:59',NULL,NULL,NULL,NULL,NULL),
	(207,'Charlton Athletic','CHA','Charlton','charlton-athletic',NULL,1,NULL,'2014-03-22 18:55:11','http://www.bbc.co.uk/sport/football/teams/charlton-athletic/fixtures','2015-07-28 19:57:00',NULL,NULL,NULL),
	(208,'Blackpool Town','BLA',NULL,'blackpool-town',NULL,1,NULL,'2014-04-02 10:00:57',NULL,NULL,NULL,NULL,NULL),
	(209,'Barnsley Town','BAR',NULL,'barnsley-town',NULL,1,NULL,'2014-04-02 10:09:37',NULL,NULL,NULL,NULL,NULL),
	(210,'Watford Town','WTF','Watford','watford-town',NULL,1,NULL,'2014-04-02 10:10:29','http://www.bbc.co.uk/sport/football/teams/watford/fixtures','2015-07-28 19:57:00',NULL,NULL,NULL),
	(228,'Algeria',NULL,NULL,'algeria',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(229,'Argentina',NULL,NULL,'argentina',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(230,'Australia',NULL,NULL,'australia',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(231,'Belgium',NULL,NULL,'belgium',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(232,'Bosnia and Herzegovina',NULL,NULL,'bosnia-and-herzegovina',NULL,1,NULL,'2014-04-03 22:02:24',NULL,'2015-07-28 07:29:00',NULL,NULL,NULL),
	(233,'Brazil',NULL,NULL,'brazil',NULL,1,NULL,'2014-04-03 22:02:24',NULL,'2015-07-28 07:29:00',NULL,NULL,NULL),
	(234,'Cameroon',NULL,NULL,'cameroon',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(235,'Chile',NULL,NULL,'chile',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(236,'Colombia',NULL,NULL,'colombia',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(237,'Costa Rica',NULL,NULL,'costa-rica',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(238,'Côte d\'Ivoire',NULL,NULL,'côte-d\'ivoire',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(239,'Croatia',NULL,NULL,'croatia',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(240,'Ecuador',NULL,NULL,'ecuador',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(241,'England',NULL,NULL,'england',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(242,'France',NULL,NULL,'france',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(243,'Germany',NULL,NULL,'germany',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(244,'Ghana',NULL,NULL,'ghana',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(245,'Greece',NULL,NULL,'greece',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(246,'Honduras',NULL,NULL,'honduras',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(247,'Iran',NULL,NULL,'iran',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(248,'Italy',NULL,NULL,'italy',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(249,'Japan',NULL,NULL,'japan',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(250,'Korea Republic',NULL,NULL,'korea-republic',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(253,'Mexico',NULL,NULL,'mexico',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(254,'Netherlands',NULL,NULL,'netherlands',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(255,'Nigeria',NULL,NULL,'nigeria',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(256,'Portugal',NULL,NULL,'portugal',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(257,'Russia',NULL,NULL,'russia',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(258,'Spain',NULL,NULL,'spain',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(259,'Switzerland',NULL,NULL,'switzerland',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(260,'Uruguay',NULL,NULL,'uruguay',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(261,'USA',NULL,NULL,'usa',NULL,1,NULL,'2014-04-03 22:02:24',NULL,NULL,NULL,NULL,NULL),
	(276,'Scotland',NULL,NULL,'scotland',NULL,1,NULL,'2015-06-12 15:17:21',NULL,NULL,NULL,NULL,NULL),
	(277,'Andy Murray',NULL,NULL,'andy-murray',NULL,1,NULL,'2015-06-12 15:48:24',NULL,NULL,NULL,NULL,NULL),
	(278,'Tim Henman',NULL,NULL,'tim-henman',NULL,5,15,'2015-06-12 15:48:24',NULL,NULL,NULL,NULL,NULL),
	(280,'Arsenal','ARS','Gunners','arsenal',20,1,35,'2015-07-01 09:22:27','http://www.bbc.co.uk/sport/football/teams/arsenal/fixtures','2015-07-28 15:41:00',27,'Arsenal','http://www.arsenal.com/'),
	(281,'West Ham United','WHU','West Ham','west-ham-united',1,1,54,'2015-07-01 09:22:27','http://www.bbc.co.uk/sport/football/teams/west-ham-united/fixtures','2015-07-28 19:52:00',62,'whufc_official','http://www.whufc.com/'),
	(282,'Ipswich Town','IPS','Ipswich, Tractor Boys','ipswich',1,1,NULL,'2015-07-17 07:20:31','http://www.bbc.co.uk/sport/football/teams/ipswich-town/fixtures',NULL,46,'Official_ITFC','http://www.itfc.co.uk/'),
	(283,'Sheffield Wednesday','SHW','Sheff Wed','sheffield-wednesday',1,1,NULL,'2015-07-17 07:21:54','',NULL,14,NULL,NULL),
	(284,'Hull City','HUL','Hull, Tigers','hull',1,1,NULL,'2015-07-17 15:25:36','',NULL,36,'HullCity','http://www.hullcitytigers.com/'),
	(285,'Cardiff City','CDF','Cardiff','cardiff',1,1,NULL,'2015-07-17 15:26:17','http://www.bbc.co.uk/sport/football/teams/cardiff-city/fixtures',NULL,17,'CardiffCityFC','http://www.cardiffcityfc.co.uk/'),
	(287,'Bolton Wanderers','BLT','Bolton','bolton-wanderers',1,1,NULL,'2015-07-17 15:35:32','http://www.bbc.co.uk/sport/football/teams/bolton-wanderers/fixtures','2015-07-28 19:57:00',16,'OfficialBWFC','http://www.bwfc.co.uk/'),
	(288,'Nottm Forest','NTF',NULL,'nottm-forest',NULL,1,NULL,'2015-07-17 15:37:18',NULL,NULL,NULL,NULL,NULL),
	(289,'Leeds United','LEE','Leeds','leeds-united',1,1,NULL,'2015-07-17 15:38:04','',NULL,26,NULL,NULL),
	(290,'Portsmouth','POR',NULL,'portsmouth',NULL,1,NULL,'2015-07-17 15:39:37','http://www.bbc.co.uk/sport/football/teams/portsmouth/fixtures','2015-07-28 20:00:00',NULL,NULL,NULL),
	(291,'Rotherham United','RTH','Rotherham, The Millers','rotherham-united',1,1,NULL,'2015-07-17 15:42:33','http://www.bbc.co.uk/sport/football/teams/rotherham-united/fixtures','2015-07-28 19:59:00',69,'officialrufc','http://www.themillers.co.uk/'),
	(292,'Queens Park Rangers','QPR','QPR','queens-park-rangers',1,1,NULL,'2015-07-17 15:43:48','http://www.bbc.co.uk/sport/football/teams/queens-park-rangers/fixtures','2015-07-28 15:39:00',39,'QPRFC','http://www.qpr.co.uk/'),
	(293,'Brentford','BRE','','brentford',1,1,NULL,'2015-07-17 15:45:24','http://www.bbc.co.uk/sport/football/teams/brentford/fixtures','2015-07-28 15:39:00',63,'BrentfordFC','http://www.brentfordfc.co.uk/'),
	(294,'MK Dons','MKD','Milton Keynes','mk-dons',1,1,NULL,'2015-07-17 15:46:24','http://www.bbc.co.uk/sport/football/teams/milton-keynes-dons/fixtures','2015-07-28 15:39:00',67,'MKDonsFC','http://www.mkdons.com/'),
	(295,'Fulham','FUL','','fulham',1,1,NULL,'2015-07-17 15:47:00','http://www.bbc.co.uk/sport/football/teams/fulham/fixtures','2015-07-28 15:39:00',22,'FulhamFC','http://www.fulhamfc.com/'),
	(296,'Preston North End','PNE','Preston','preston-north-end',1,1,NULL,'2015-07-17 15:49:12','http://www.bbc.co.uk/sport/football/teams/preston-north-end/fixtures','2015-07-28 15:38:00',68,'pnefc','http://www.pnefc.net/'),
	(297,'Reading','REA','ROyals','reading',1,1,NULL,'2015-07-17 15:51:25','http://www.bbc.co.uk/sport/football/teams/reading/fixtures','2015-07-28 15:38:00',41,'ReadingFC','http://www.readingfc.co.uk/'),
	(298,'Southend','SOD',NULL,'southend',NULL,1,NULL,'2015-07-18 10:06:18',NULL,NULL,NULL,NULL,NULL),
	(299,'Port Vale','POV',NULL,'port-vale',NULL,1,NULL,'2015-07-18 10:11:13',NULL,NULL,NULL,NULL,NULL),
	(300,'Walsall','WAL',NULL,'walsall',NULL,1,NULL,'2015-07-18 10:22:17',NULL,NULL,NULL,NULL,NULL),
	(301,'Manchester United','MNU','Man Utd','manchester-united',NULL,1,45,'2015-07-20 17:40:33','http://kickoff.dev/bbc-man-utd.html','2015-07-28 20:02:00',45,'ManUtd','http://www.manutd.com/'),
	(302,'Bournemouth','BOU','AFC Bournemouth','bournemouth',20,1,55,'2015-07-27 17:50:18','http://www.bbc.co.uk/sport/football/teams/afc-bournemouth/fixtures','2015-07-28 15:38:00',23,'afcbournemouth','http://www.afcb.co.uk/'),
	(303,'Norwich City','NOR','Norwich','norwich-city',20,1,56,'2015-07-27 17:51:15','http://www.bbc.co.uk/sport/football/teams/norwich-city/fixtures','2015-07-28 15:38:00',18,'NorwichCityFC','http://www.canaries.co.uk/'),
	(304,'Leicester City','LEI','Leicester, Foxes','leicester-city',20,1,NULL,'2015-07-27 17:55:11','',NULL,37,NULL,NULL),
	(305,'Tottenham Hotspur','TOT','Tottenham, Spurs','tottenham-hotspur',20,1,52,'2015-07-27 17:56:04','http://www.bbc.co.uk/sport/football/teams/tottenham-hotspur/fixtures','2015-07-28 15:38:00',61,'SpursOfficial','http://www.tottenhamhotspur.com/'),
	(306,'Everton','EVE','','everton',20,1,40,'2015-07-27 17:58:29','http://www.bbc.co.uk/sport/football/teams/everton/fixtures','2015-07-28 15:38:00',31,'Everton','http://www.evertonfc.com/'),
	(307,'Manchester City','MNC','Man City','manchester-city',20,1,44,'2015-07-27 17:58:50','http://www.bbc.co.uk/sport/football/teams/manchester-city/fixtures','2015-07-28 15:38:00',20,'MCFC','https://www.mcfc.co.uk/'),
	(308,'West Bromwich Albion','WBA','West Brom','west-bromwich-albion',20,1,53,'2015-07-27 17:59:13','http://www.bbc.co.uk/sport/football/teams/west-bromwich-albion/fixtures','2015-07-28 15:38:00',32,'wbafcofficial','http://www.wba.co.uk/'),
	(309,'Sunderland','SUN','','sunderland',20,1,50,'2015-07-27 18:00:31','http://www.bbc.co.uk/sport/football/teams/sunderland/fixtures','2015-07-28 07:33:00',54,'SunderlandAFC','http://www.safc.com/'),
	(310,'Stoke City','STO','Stoke','stoke-city',20,1,49,'2015-07-27 18:01:30','http://www.bbc.co.uk/sport/football/teams/stoke-city/fixtures','2015-07-28 07:30:00',15,'stokecity','http://www.stokecityfc.com/'),
	(311,'Southampton','SOU','','southampton',20,1,48,'2015-07-27 18:01:55','http://www.bbc.co.uk/sport/football/teams/southampton/fixtures','2015-07-28 07:30:00',52,'SouthamptonFC','http://www.saintsfc.co.uk/'),
	(312,'Newcastle United','NEW','Newcastle','newcastle-united',20,1,46,'2015-07-28 06:31:18','http://www.bbc.co.uk/sport/football/teams/newcastle-united/fixtures','2015-07-28 07:30:00',51,'NUFC','http://www.nufc.co.uk/'),
	(313,'Liverpool','LIV','','liverpool',20,1,43,'2015-07-28 06:31:28','http://www.bbc.co.uk/sport/football/teams/liverpool/fixtures','2015-07-28 07:30:00',8,'LFC','http://www.liverpoolfc.com/'),
	(314,'Colchester','COL',NULL,'colchester',NULL,1,NULL,'2015-07-28 15:38:53',NULL,NULL,NULL,NULL,NULL),
	(315,'Crewe','CRE',NULL,'crewe',NULL,1,NULL,'2015-07-28 15:38:57',NULL,NULL,NULL,NULL,NULL),
	(316,'Wycombe',NULL,NULL,'wycombe',NULL,1,NULL,'2015-07-28 15:39:03',NULL,NULL,NULL,NULL,NULL),
	(317,'Leyton Orient',NULL,NULL,'leyton-orient',NULL,1,NULL,'2015-07-28 15:39:10',NULL,NULL,NULL,NULL,NULL),
	(318,'Oxford Utd',NULL,NULL,'oxford-utd',NULL,1,NULL,'2015-07-28 15:39:19',NULL,NULL,NULL,NULL,NULL),
	(319,'Yeovil',NULL,NULL,'yeovil',NULL,1,NULL,'2015-07-28 15:39:34',NULL,NULL,NULL,NULL,NULL),
	(320,'Mansfield',NULL,NULL,'mansfield',NULL,1,NULL,'2015-07-28 19:57:05',NULL,NULL,NULL,NULL,NULL),
	(321,'Burton',NULL,NULL,'burton',NULL,1,NULL,'2015-07-28 19:57:57',NULL,NULL,NULL,NULL,NULL),
	(322,'Bristol Rovers',NULL,NULL,'bristol-rovers',NULL,1,NULL,'2015-07-28 19:58:51',NULL,NULL,NULL,NULL,NULL),
	(323,'Cambridge',NULL,NULL,'cambridge',NULL,1,NULL,'2015-07-28 19:59:03',NULL,NULL,NULL,NULL,NULL),
	(324,'Oldham',NULL,NULL,'oldham',NULL,1,NULL,'2015-07-28 19:59:26',NULL,NULL,NULL,NULL,NULL),
	(325,'Wimbledon',NULL,NULL,'wimbledon',NULL,1,NULL,'2015-07-28 19:59:39',NULL,NULL,NULL,NULL,NULL),
	(326,'Shrewsbury',NULL,NULL,'shrewsbury',NULL,1,NULL,'2015-07-28 19:59:51',NULL,NULL,NULL,NULL,NULL),
	(327,'Notts County',NULL,NULL,'notts-county',NULL,1,NULL,'2015-07-28 20:00:03',NULL,NULL,NULL,NULL,NULL),
	(328,'Accrington',NULL,NULL,'accrington',NULL,1,NULL,'2015-07-28 20:01:02',NULL,NULL,NULL,NULL,NULL),
	(329,'Doncaster',NULL,NULL,'doncaster',NULL,1,NULL,'2015-07-28 20:01:11',NULL,NULL,NULL,NULL,NULL),
	(330,'Luton',NULL,NULL,'luton',NULL,1,NULL,'2015-07-28 20:01:30',NULL,NULL,NULL,NULL,NULL),
	(331,'Stevenage',NULL,NULL,'stevenage',NULL,1,NULL,'2015-07-28 20:01:37',NULL,NULL,NULL,NULL,NULL),
	(332,'Newport',NULL,NULL,'newport',NULL,1,NULL,'2015-07-28 20:02:01',NULL,NULL,NULL,NULL,NULL),
	(333,'Weedon Juniors Red U9',NULL,NULL,'weedon-juniors-red-u9',NULL,1,NULL,'2015-09-05 09:00:32',NULL,NULL,NULL,NULL,NULL),
	(334,'Daventry Rangers U9s',NULL,NULL,'daventry-rangers-u9s',NULL,1,NULL,'2015-11-03 22:34:10',NULL,NULL,NULL,NULL,NULL),
	(335,'Moulton Magpies White U9',NULL,NULL,'moulton-magpies-white-u9',NULL,1,NULL,'2015-12-07 18:01:48',NULL,NULL,NULL,NULL,NULL),
	(336,'Hartlepool',NULL,NULL,'hartlepool',NULL,1,NULL,'2016-01-01 22:36:52',NULL,NULL,NULL,NULL,NULL),
	(337,'Crick Colts U10',NULL,NULL,'crick-colts-u10',NULL,1,NULL,'2016-01-10 21:23:44',NULL,NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table themes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `themes`;

CREATE TABLE `themes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `primary_colour` varchar(11) DEFAULT NULL,
  `secondary_colour` varchar(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `themes` WRITE;
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;

INSERT INTO `themes` (`id`, `name`, `image`, `icon`, `primary_colour`, `secondary_colour`, `created`, `status`)
VALUES
	(15,'Chameleon Green','files/chameleon_reptilia_wallpaper_1600x1200.jpg',NULL,'60,180,60',NULL,'2014-04-02 06:14:14',NULL),
	(19,'Tea','files/shutterstock_52215466.jpg',NULL,'120,90,40',NULL,'2014-04-02 06:21:51',NULL),
	(20,'DJ','files/8332_127034295841_1794403_n.jpg',NULL,'40,40,40',NULL,'2014-04-02 06:29:01',NULL),
	(21,'Formula 1','files/F1_McLaren_and_ASOS.png',NULL,'50,50,50',NULL,'2014-04-02 06:38:46',NULL),
	(22,'Ruggers','files/rugby.jpg',NULL,'30,90,30',NULL,'2014-04-02 07:42:21',NULL),
	(23,'Basketball Court','files/8798121_basketball_court.jpg',NULL,'',NULL,'2014-04-02 07:55:10',NULL),
	(24,'Baseball Low','files/4571236155.jpg',NULL,'',NULL,'2014-04-02 07:55:28',NULL),
	(25,'American Football CU','files/American_football_in_Tel_Aviv_Israel.jpg',NULL,'',NULL,'2014-04-02 07:55:54',NULL),
	(26,'Back of the Net','files/close_up_football_goal_1341825905.jpg',NULL,'0,0,0',NULL,'2014-04-02 07:56:37',NULL),
	(27,'Cricket Ball','files/cricket_ball.jpg',NULL,'',NULL,'2014-04-02 07:56:59',NULL),
	(28,'On Your Marks','files/Fields_wallpapers_2721.jpg',NULL,'',NULL,'2014-04-02 07:57:19',NULL),
	(29,'Spinning Tennis','files/Global_Tennis_Adviser.jpg',NULL,'',NULL,'2014-04-02 08:00:17',NULL),
	(30,'Pride Park East','files/DerbyCountyEastStand.JPG',NULL,'',NULL,'2014-04-02 09:24:56',NULL),
	(31,'Rio','files/rio.jpg',NULL,'180,220,255',NULL,'2014-04-09 14:27:50',NULL),
	(32,'Barclays Premiership','files/maxresdefault2.jpg',NULL,'#2b3d8a',NULL,'2015-12-14 18:08:52',NULL),
	(33,'FA Cup','files/fa_cup.jpg',NULL,'#a91616',NULL,'2015-12-14 18:10:48',NULL),
	(34,'Championship','files/championship_trophy_64064_2476237_613x460.jpg',NULL,'#434343',NULL,'2015-12-14 18:11:13',NULL),
	(35,'Arsenal',NULL,NULL,'#EF0107','#003276','2016-06-06 20:31:27',NULL),
	(36,'Aston Villa',NULL,NULL,'#660132','#A2C4E9','2016-06-06 20:32:07',NULL),
	(37,'Burnley',NULL,NULL,'#70193D','#93C6E0','2016-06-06 20:33:19',NULL),
	(38,'Chelsea',NULL,NULL,'#034695','#CFA63D','2016-06-06 20:33:33',NULL),
	(39,'Crystal Palace',NULL,NULL,'#0054A4','#D81E05','2016-06-06 20:33:55',NULL),
	(40,'Everton',NULL,NULL,'#00369C','#FFFFFF','2016-06-06 20:34:15',NULL),
	(41,'Hull City',NULL,NULL,'#F5A12D','#000000','2016-06-06 20:34:30',NULL),
	(42,'Leicester City',NULL,NULL,'#273E8A','#FFB73E','2016-06-06 20:34:46',NULL),
	(43,'Liverpool',NULL,NULL,'#E31B23','#00997C','2016-06-06 20:34:57',NULL),
	(44,'Manchester City',NULL,NULL,'#5CBFEB','#FFD156','2016-06-06 20:35:43',NULL),
	(45,'Manchester United',NULL,NULL,'#DA020E','#FDE60C','2016-06-06 20:35:57',NULL),
	(46,'Newcastle United',NULL,NULL,'#231F20','#15ADFF','2016-06-06 20:36:32',NULL),
	(47,'QPR',NULL,NULL,'#023DF9','#FFFFFF','2016-06-06 20:36:50',NULL),
	(48,'Southampton',NULL,NULL,'#ED1A3B','#FFFFFF','2016-06-06 20:37:08',NULL),
	(49,'Stoke City',NULL,NULL,'#D7172F','#000000','2016-06-06 20:37:25',NULL),
	(50,'Sunderland',NULL,NULL,'#DB001B','#FFFFFF','2016-06-06 20:37:37',NULL),
	(51,'Swansea City',NULL,NULL,'#000000','#FFFFFF','2016-06-06 20:37:51',NULL),
	(52,'Tottenham Hotspur',NULL,NULL,'#0F204B','#FFFFFF','2016-06-06 20:38:19',NULL),
	(53,'West Brom',NULL,NULL,'#002868','#000000','2016-06-06 20:38:29',NULL),
	(54,'West Ham',NULL,NULL,'#551724','#47A2E0','2016-06-06 20:38:41',NULL),
	(55,'Bournemouth',NULL,NULL,'#E62333',NULL,'2016-06-06 20:53:56',NULL),
	(56,'Norwich',NULL,NULL,'#00a94f',NULL,'2016-06-06 20:58:27',NULL),
	(57,'Watford',NULL,NULL,'#f32837',NULL,'2016-06-06 21:01:05',NULL);

/*!40000 ALTER TABLE `themes` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
