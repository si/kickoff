# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: 127.0.01 (MySQL 5.5.42)
# Database: kickoff_dev
# Generation Time: 2016-06-15 21:46:42 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table themes
# ------------------------------------------------------------

DROP TABLE IF EXISTS `themes`;

CREATE TABLE `themes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `primary_colour` varchar(11) DEFAULT NULL,
  `secondary_colour` varchar(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `status` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `themes` WRITE;
/*!40000 ALTER TABLE `themes` DISABLE KEYS */;

INSERT INTO `themes` (`id`, `name`, `image`, `icon`, `primary_colour`, `secondary_colour`, `created`, `status`)
VALUES
	(15,'Chameleon Green','files/chameleon_reptilia_wallpaper_1600x1200.jpg',NULL,'60,180,60',NULL,'2014-04-02 06:14:14',NULL),
	(19,'Tea','files/shutterstock_52215466.jpg',NULL,'120,90,40',NULL,'2014-04-02 06:21:51',NULL),
	(20,'DJ','files/8332_127034295841_1794403_n.jpg',NULL,'40,40,40',NULL,'2014-04-02 06:29:01',NULL),
	(21,'Formula 1','files/F1_McLaren_and_ASOS.png',NULL,'50,50,50',NULL,'2014-04-02 06:38:46',NULL),
	(22,'Ruggers','files/rugby.jpg',NULL,'30,90,30',NULL,'2014-04-02 07:42:21',NULL),
	(23,'Basketball Court','files/8798121_basketball_court.jpg',NULL,'',NULL,'2014-04-02 07:55:10',NULL),
	(24,'Baseball Low','files/4571236155.jpg',NULL,'',NULL,'2014-04-02 07:55:28',NULL),
	(25,'American Football CU','files/American_football_in_Tel_Aviv_Israel.jpg',NULL,'',NULL,'2014-04-02 07:55:54',NULL),
	(26,'Back of the Net','files/close_up_football_goal_1341825905.jpg',NULL,'0,0,0',NULL,'2014-04-02 07:56:37',NULL),
	(27,'Cricket Ball','files/cricket_ball.jpg',NULL,'',NULL,'2014-04-02 07:56:59',NULL),
	(28,'On Your Marks','files/Fields_wallpapers_2721.jpg',NULL,'',NULL,'2014-04-02 07:57:19',NULL),
	(29,'Spinning Tennis','files/Global_Tennis_Adviser.jpg',NULL,'',NULL,'2014-04-02 08:00:17',NULL),
	(30,'Pride Park East','files/DerbyCountyEastStand.JPG',NULL,'',NULL,'2014-04-02 09:24:56',NULL),
	(31,'Rio','files/rio.jpg',NULL,'180,220,255',NULL,'2014-04-09 14:27:50',NULL),
	(32,'Barclays Premiership','files/maxresdefault2.jpg',NULL,'#2b3d8a',NULL,'2015-12-14 18:08:52',NULL),
	(33,'FA Cup','files/fa_cup.jpg',NULL,'#a91616',NULL,'2015-12-14 18:10:48',NULL),
	(34,'Championship','files/championship_trophy_64064_2476237_613x460.jpg',NULL,'#434343',NULL,'2015-12-14 18:11:13',NULL),
	(35,'Arsenal',NULL,NULL,'#EF0107','#003276','2016-06-06 20:31:27',NULL),
	(36,'Aston Villa',NULL,NULL,'#660132','#A2C4E9','2016-06-06 20:32:07',NULL),
	(37,'Burnley',NULL,NULL,'#70193D','#93C6E0','2016-06-06 20:33:19',NULL),
	(38,'Chelsea',NULL,NULL,'#034695','#CFA63D','2016-06-06 20:33:33',NULL),
	(39,'Crystal Palace',NULL,NULL,'#0054A4','#D81E05','2016-06-06 20:33:55',NULL),
	(40,'Everton',NULL,NULL,'#00369C','#FFFFFF','2016-06-06 20:34:15',NULL),
	(41,'Hull City',NULL,NULL,'#F1AE00','#000000','2016-06-06 20:34:30',NULL),
	(42,'Leicester City',NULL,NULL,'#273E8A','#FFB73E','2016-06-06 20:34:46',NULL),
	(43,'Liverpool',NULL,NULL,'#E31B23','#00997C','2016-06-06 20:34:57',NULL),
	(44,'Manchester City',NULL,NULL,'#5CBFEB','#FFD156','2016-06-06 20:35:43',NULL),
	(45,'Manchester United',NULL,NULL,'#DA020E','#FDE60C','2016-06-06 20:35:57',NULL),
	(46,'Newcastle United',NULL,NULL,'#231F20','#15ADFF','2016-06-06 20:36:32',NULL),
	(47,'QPR',NULL,NULL,'#023DF9','#FFFFFF','2016-06-06 20:36:50',NULL),
	(48,'Southampton',NULL,NULL,'#ED1A3B','#FFFFFF','2016-06-06 20:37:08',NULL),
	(49,'Stoke City',NULL,NULL,'#D7172F','#000000','2016-06-06 20:37:25',NULL),
	(50,'Sunderland',NULL,NULL,'#DB001B','#FFFFFF','2016-06-06 20:37:37',NULL),
	(51,'Swansea City',NULL,NULL,'#000000','#FFFFFF','2016-06-06 20:37:51',NULL),
	(52,'Tottenham Hotspur',NULL,NULL,'#0F204B','#FFFFFF','2016-06-06 20:38:19',NULL),
	(53,'West Brom',NULL,NULL,'#002868','#000000','2016-06-06 20:38:29',NULL),
	(54,'West Ham',NULL,NULL,'#551724','#47A2E0','2016-06-06 20:38:41',NULL),
	(55,'Bournemouth',NULL,NULL,'#E62333',NULL,'2016-06-06 20:53:56',NULL),
	(56,'Norwich',NULL,NULL,'#00a94f',NULL,'2016-06-06 20:58:27',NULL),
	(57,'Watford',NULL,NULL,'#f32837',NULL,'2016-06-06 21:01:05',NULL),
	(58,'Middlesbrough',NULL,NULL,'#ef3e42','#FFFFFFF',NULL,NULL);

/*!40000 ALTER TABLE `themes` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
