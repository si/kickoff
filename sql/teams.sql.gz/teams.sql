# ************************************************************
# Sequel Pro SQL dump
# Version 4541
#
# http://www.sequelpro.com/
# https://github.com/sequelpro/sequelpro
#
# Host: eu-cdbr-west-01.cleardb.com (MySQL 5.5.40-log)
# Database: heroku_18f051336d4db01
# Generation Time: 2016-06-22 19:34:25 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table teams
# ------------------------------------------------------------

DROP TABLE IF EXISTS `teams`;

CREATE TABLE `teams` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `competition_id` int(11) DEFAULT NULL,
  `name` varchar(30) DEFAULT NULL,
  `short` varchar(10) DEFAULT NULL,
  `aliases` varchar(255) DEFAULT NULL,
  `slug` varchar(40) DEFAULT NULL,
  `twitter` varchar(15) DEFAULT NULL,
  `website` varchar(100) DEFAULT NULL,
  `theme_id` int(11) DEFAULT NULL,
  `events_import_url` varchar(255) DEFAULT NULL,
  `sport_id` int(11) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `events_import_updated` datetime DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `teams` WRITE;
/*!40000 ALTER TABLE `teams` DISABLE KEYS */;

INSERT INTO `teams` (`id`, `competition_id`, `name`, `short`, `aliases`, `slug`, `twitter`, `website`, `theme_id`, `events_import_url`, `sport_id`, `created`, `events_import_updated`, `location_id`)
VALUES
	(69,1,'Derby County','DER','Derby, Rams','derby-county','dcfcofficial','http://www.dcfc.co.uk/',30,'http://www.bbc.co.uk/sport/football/teams/derby-county/fixtures',1,'2014-03-06 18:22:51','2016-06-15 20:34:00',47),
	(70,NULL,'Doncaster Rovers','DON','Doncaster','doncaster-rovers',NULL,NULL,NULL,NULL,1,'2014-03-06 18:22:51',NULL,NULL),
	(71,1,'Brighton & Hove Albion','BRI','Brighton','brighton-hove-albion','officialbhafc','http://www.seagulls.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/brighton-and-hove-albion/fixtures',1,'2014-03-06 18:22:51','2016-06-15 20:32:00',64),
	(75,1,'Leeds United','LEE','Leeds','leeds-united','LUFC','http://www.leedsunited.com/',NULL,'http://www.bbc.co.uk/sport/football/teams/leeds-united/fixtures',1,'2014-03-06 18:22:51','2016-06-15 20:33:00',26),
	(76,20,'Watford Town','WAT','Watford, Hornets','watford-town','WatfordFC','http://www.watfordfc.com/',57,'http://www.bbc.co.uk/sport/football/teams/watford/fixtures',1,'2014-03-06 18:22:51','2016-06-15 20:23:00',59),
	(78,20,'Leicester City','LEI','Leicester, Foxes','leicester-city','LCFC','http://www.lcfc.com/',42,'http://www.bbc.co.uk/sport/football/teams/leicester-city/fixtures',1,'2014-03-06 18:22:51','2016-06-15 20:33:00',37),
	(82,1,'Wolverhampton Wanderers','WLV','Wolves','wolverhampton-wanderers','officialwolves','http://www.wolves.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/wolverhampton-wanderers/fixtures',1,'2014-03-06 18:22:51','2016-06-15 20:34:00',43),
	(85,20,'Burnley','BUR','','burnley','BurnleyOfficial','http://www.burnleyfootballclub.com/',NULL,'http://www.bbc.co.uk/sport/football/teams/burnley/fixtures',1,'2014-03-06 18:22:51','2016-06-15 20:27:00',56),
	(91,1,'Huddersfield Town','HUD','Huddersfield, Terriers','huddersfield-town','htafcdotcom','http://www.htafc.com/',NULL,'http://www.bbc.co.uk/sport/football/teams/huddersfield-town/fixtures',1,'2014-03-06 18:22:51','2016-06-15 20:33:00',66),
	(94,NULL,'Bradford','BRD',NULL,'bradford',NULL,NULL,NULL,NULL,1,'2014-03-06 18:22:51',NULL,NULL),
	(96,1,'Aston Villa','AST','Villa','aston-villa','AVFCOfficial','http://www.avfc.co.uk/',36,'http://www.bbc.co.uk/sport/football/teams/aston-villa/fixtures',1,'2014-03-06 18:22:51','2016-06-15 20:32:00',60),
	(132,1,'Nottingham Forest','NTF','Nottm Forest, Forest','nottingham-forest','Official_NFFC','http://www.nottinghamforest.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/nottingham-forest/fixtures',1,'2014-03-06 18:23:01','2016-06-15 20:30:00',19),
	(134,20,'Crystal Palace','CRP','','crystal-palace','CPFC','http://www.cpfc.co.uk/',39,'http://www.bbc.co.uk/sport/football/teams/crystal-palace/fixtures',1,'2014-03-06 18:23:01','2016-06-15 20:27:00',53),
	(136,NULL,'Peterborough','PET',NULL,'peterborough',NULL,NULL,NULL,NULL,1,'2014-03-06 18:23:01',NULL,NULL),
	(137,1,'Bristol City','BRC','Robins','bristol-city','bcfctweets','http://www.bcfc.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/bristol-city/fixtures',1,'2014-03-06 18:23:01','2016-06-15 20:33:00',65),
	(143,1,'Blackburn Rovers','BLK','Blackburn','blackburn-rovers','onerovers','http://www.rovers.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/blackburn-rovers/fixtures',1,'2014-03-06 18:23:01','2016-06-15 20:32:00',28),
	(150,20,'Middlesbrough','MID','','middlesbrough','Boro','http://www.mfc.co.uk/',58,'http://www.bbc.co.uk/sport/football/teams/middlesbrough/fixtures',1,'2014-03-06 18:23:01','2016-06-15 20:32:00',48),
	(151,1,'Birmingham City','BIR','Birmingham','birmingham-city','BCFC','http://www.bcfc.com/',NULL,'http://www.bbc.co.uk/sport/football/teams/birmingham-city/fixtures',1,'2014-03-06 18:23:01','2016-06-15 20:31:00',50),
	(154,1,'Charlton Athletic','CHA','Charlton','charlton-athletic','CAFCofficial','http://www.cafc.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/charlton-athletic/fixtures',1,'2014-03-06 18:23:01','2016-06-15 20:23:00',57),
	(156,1,'Sheffield Wednesday','SHW','Sheff Wed, Sheffield Wed, Wednesday, Owls','sheffield-wednesday','swfc','http://www.swfc.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/sheffield-wednesday/fixtures',1,'2014-03-06 18:23:01','2016-06-15 20:30:00',35),
	(157,NULL,'Scunthorpe','SCU',NULL,'scunthorpe',NULL,NULL,NULL,NULL,1,'2014-03-06 18:23:01',NULL,NULL),
	(158,NULL,'Millwall','MIL',NULL,'millwall',NULL,NULL,NULL,NULL,1,'2014-03-06 18:23:01',NULL,NULL),
	(160,20,'Swansea City','SWC','Swansea','swansea-city','SwansOfficial','http://www.swanseacity.net/',51,'http://www.bbc.co.uk/sport/football/teams/swansea-city/fixtures',1,'2014-03-06 18:23:01','2016-06-15 20:27:00',38),
	(162,20,'Chelsea','CHE','','chelsea','ChelseaFC','https://www.chelseafc.com/',38,'http://www.bbc.co.uk/sport/football/teams/chelsea/fixtures',1,'2014-03-06 18:23:01','2016-06-15 20:27:00',55),
	(208,NULL,'Blackpool Town','BLA','Blackpool','blackpool-town',NULL,NULL,NULL,NULL,1,'2014-04-02 10:00:57',NULL,NULL),
	(209,NULL,'Barnsley Town','BAR','Barnsley','barnsley-town',NULL,NULL,NULL,NULL,1,'2014-04-02 10:09:37',NULL,NULL),
	(280,20,'Arsenal','ARS','Gunners','arsenal','Arsenal','http://www.arsenal.com/',35,'http://www.bbc.co.uk/sport/football/teams/arsenal/fixtures',1,'2015-07-01 09:22:27','2016-06-15 20:26:00',27),
	(281,20,'West Ham United','WHU','West Ham','west-ham-united','whufc_official','http://www.whufc.com/',54,'http://www.bbc.co.uk/sport/football/teams/west-ham-united/fixtures',1,'2015-07-01 09:22:27','2016-06-15 20:30:00',62),
	(282,1,'Ipswich Town','IPS','Ipswich, Tractor Boys','ipswich','Official_ITFC','http://www.itfc.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/ipswich-town/fixtures',1,'2015-07-17 07:20:31','2016-06-15 20:35:00',46),
	(284,20,'Hull City','HUL','Hull, Tigers','hull','HullCity','http://www.hullcitytigers.com/',41,'http://www.bbc.co.uk/sport/football/teams/hull-city/fixtures',1,'2015-07-17 15:25:36','2016-06-15 20:23:00',36),
	(285,1,'Cardiff City','CDF','Cardiff','cardiff','CardiffCityFC','http://www.cardiffcityfc.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/cardiff-city/fixtures',1,'2015-07-17 15:26:17','2016-06-15 20:23:00',17),
	(287,1,'Bolton Wanderers','BLT','Bolton','bolton-wanderers','OfficialBWFC','http://www.bwfc.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/bolton-wanderers/fixtures',1,'2015-07-17 15:35:32','2016-06-15 20:30:00',16),
	(290,NULL,'Portsmouth','POR',NULL,'portsmouth',NULL,NULL,NULL,'http://www.bbc.co.uk/sport/football/teams/portsmouth/fixtures',1,'2015-07-17 15:39:37','2016-06-15 20:32:00',NULL),
	(291,1,'Rotherham United','RTH','Rotherham, The Millers','rotherham-united','officialrufc','http://www.themillers.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/rotherham-united/fixtures',1,'2015-07-17 15:42:33','2016-06-15 20:32:00',69),
	(292,1,'Queens Park Rangers','QPR','QPR','queens-park-rangers','QPRFC','§',NULL,'http://www.bbc.co.uk/sport/football/teams/queens-park-rangers/fixtures',1,'2015-07-17 15:43:48','2016-06-15 20:26:00',39),
	(293,1,'Brentford','BRE','','brentford','BrentfordFC','http://www.brentfordfc.co.uk/',NULL,'http://www.bbc.co.uk/sport/football/teams/brentford/fixtures',1,'2015-07-17 15:45:24','2016-06-15 20:26:00',63),
	(294,1,'MK Dons','MKD','Milton Keynes','mk-dons','MKDonsFC','http://www.mkdons.com/',NULL,'http://www.bbc.co.uk/sport/football/teams/milton-keynes-dons/fixtures',1,'2015-07-17 15:46:24','2016-06-15 20:26:00',67),
	(295,1,'Fulham','FUL','','fulham','FulhamFC','http://www.fulhamfc.com/',NULL,'http://www.bbc.co.uk/sport/football/teams/fulham/fixtures',1,'2015-07-17 15:47:00','2016-06-15 20:26:00',22),
	(296,1,'Preston North End','PNE','Preston','preston-north-end','pnefc','http://www.pnefc.net/',NULL,'http://www.bbc.co.uk/sport/football/teams/preston-north-end/fixtures',1,'2015-07-17 15:49:12','2016-06-15 20:25:00',68),
	(297,1,'Reading','REA','ROyals','reading','ReadingFC','§',NULL,'http://www.bbc.co.uk/sport/football/teams/reading/fixtures',1,'2015-07-17 15:51:25','2016-06-15 20:24:00',41),
	(298,NULL,'Southend','SOD',NULL,'southend',NULL,NULL,NULL,NULL,1,'2015-07-18 10:06:18',NULL,NULL),
	(299,NULL,'Port Vale','POV',NULL,'port-vale',NULL,NULL,NULL,NULL,1,'2015-07-18 10:11:13',NULL,NULL),
	(300,NULL,'Walsall','WAL',NULL,'walsall',NULL,NULL,NULL,NULL,1,'2015-07-18 10:22:17',NULL,NULL),
	(301,20,'Manchester United','MNU','Man Utd','manchester-united','ManUtd','http://www.manutd.com/',45,'http://www.bbc.co.uk/sport/football/teams/manchester-united/fixtures',1,'2015-07-20 17:40:33','2016-06-15 20:34:00',45),
	(302,20,'Bournemouth','BOU','AFC Bournemouth','bournemouth','afcbournemouth','http://www.afcb.co.uk/',55,'http://www.bbc.co.uk/sport/football/teams/afc-bournemouth/fixtures',1,'2015-07-27 17:50:18','2016-06-15 20:25:00',23),
	(303,1,'Norwich City','NOR','Norwich','norwich-city','NorwichCityFC','http://www.canaries.co.uk/',56,'http://www.bbc.co.uk/sport/football/teams/norwich-city/fixtures',1,'2015-07-27 17:51:15','2016-06-15 20:26:00',18),
	(305,20,'Tottenham Hotspur','TOT','Tottenham, Spurs','tottenham-hotspur','SpursOfficial','http://www.tottenhamhotspur.com/',52,'http://www.bbc.co.uk/sport/football/teams/tottenham-hotspur/fixtures',1,'2015-07-27 17:56:04','2016-06-15 20:25:00',61),
	(306,20,'Everton','EVE','','everton','Everton','http://www.evertonfc.com/',40,'http://www.bbc.co.uk/sport/football/teams/everton/fixtures',1,'2015-07-27 17:58:29','2016-06-15 20:25:00',31),
	(307,20,'Manchester City','MNC','Man City','manchester-city','MCFC','https://www.mcfc.co.uk/',44,'http://www.bbc.co.uk/sport/football/teams/manchester-city/fixtures',1,'2015-07-27 17:58:50','2016-06-15 20:25:00',20),
	(308,20,'West Bromwich Albion','WBA','West Brom','west-bromwich-albion','wbafcofficial','http://www.wba.co.uk/',53,'http://www.bbc.co.uk/sport/football/teams/west-bromwich-albion/fixtures',1,'2015-07-27 17:59:13','2016-06-15 20:25:00',32),
	(309,20,'Sunderland','SUN','','sunderland','SunderlandAFC','http://www.safc.com/',50,'http://www.bbc.co.uk/sport/football/teams/sunderland/fixtures',1,'2015-07-27 18:00:31','2016-06-15 20:24:00',54),
	(310,20,'Stoke City','STO','Stoke','stoke-city','stokecity','http://www.stokecityfc.com/',49,'http://www.bbc.co.uk/sport/football/teams/stoke-city/fixtures',1,'2015-07-27 18:01:30','2016-06-15 20:23:00',15),
	(311,20,'Southampton','SOU','','southampton','SouthamptonFC','http://www.saintsfc.co.uk/',48,'http://www.bbc.co.uk/sport/football/teams/southampton/fixtures',1,'2015-07-27 18:01:55','2016-06-15 20:23:00',52),
	(312,1,'Newcastle United','NEW','Newcastle','newcastle-united','NUFC','http://www.nufc.co.uk/',46,'http://www.bbc.co.uk/sport/football/teams/newcastle-united/fixtures',1,'2015-07-28 06:31:18','2016-06-15 20:23:00',51),
	(313,20,'Liverpool','LIV','','liverpool','LFC','http://www.liverpoolfc.com/',43,'http://www.bbc.co.uk/sport/football/teams/liverpool/fixtures',1,'2015-07-28 06:31:28','2016-06-15 20:35:00',8),
	(314,NULL,'Colchester','COL',NULL,'colchester',NULL,NULL,NULL,NULL,1,'2015-07-28 15:38:53',NULL,NULL),
	(315,NULL,'Crewe','CRE',NULL,'crewe',NULL,NULL,NULL,NULL,1,'2015-07-28 15:38:57',NULL,NULL),
	(316,NULL,'Wycombe',NULL,NULL,'wycombe',NULL,NULL,NULL,NULL,1,'2015-07-28 15:39:03',NULL,NULL),
	(317,NULL,'Leyton Orient',NULL,NULL,'leyton-orient',NULL,NULL,NULL,NULL,1,'2015-07-28 15:39:10',NULL,NULL),
	(318,NULL,'Oxford Utd',NULL,NULL,'oxford-utd',NULL,NULL,NULL,NULL,1,'2015-07-28 15:39:19',NULL,NULL),
	(319,NULL,'Yeovil',NULL,NULL,'yeovil',NULL,NULL,NULL,NULL,1,'2015-07-28 15:39:34',NULL,NULL),
	(320,NULL,'Mansfield',NULL,NULL,'mansfield',NULL,NULL,NULL,NULL,1,'2015-07-28 19:57:05',NULL,NULL),
	(321,NULL,'Burton',NULL,NULL,'burton',NULL,NULL,NULL,NULL,1,'2015-07-28 19:57:57',NULL,NULL),
	(322,NULL,'Bristol Rovers',NULL,NULL,'bristol-rovers',NULL,NULL,NULL,NULL,1,'2015-07-28 19:58:51',NULL,NULL),
	(323,NULL,'Cambridge',NULL,NULL,'cambridge',NULL,NULL,NULL,NULL,1,'2015-07-28 19:59:03',NULL,NULL),
	(324,NULL,'Oldham',NULL,NULL,'oldham',NULL,NULL,NULL,NULL,1,'2015-07-28 19:59:26',NULL,NULL),
	(325,NULL,'Wimbledon',NULL,NULL,'wimbledon',NULL,NULL,NULL,NULL,1,'2015-07-28 19:59:39',NULL,NULL),
	(326,NULL,'Shrewsbury',NULL,NULL,'shrewsbury',NULL,NULL,NULL,NULL,1,'2015-07-28 19:59:51',NULL,NULL),
	(327,NULL,'Nottingham County','NTC','Notts County','notts-county',NULL,NULL,NULL,NULL,1,'2015-07-28 20:00:03',NULL,NULL),
	(330,NULL,'Luton',NULL,NULL,'luton',NULL,NULL,NULL,NULL,1,'2015-07-28 20:01:30',NULL,NULL),
	(331,NULL,'Stevenage',NULL,NULL,'stevenage',NULL,NULL,NULL,NULL,1,'2015-07-28 20:01:37',NULL,NULL),
	(332,NULL,'Newport',NULL,NULL,'newport',NULL,NULL,NULL,NULL,1,'2015-07-28 20:02:01',NULL,NULL),
	(336,NULL,'Hartlepool',NULL,NULL,'hartlepool',NULL,NULL,NULL,NULL,1,'2016-01-01 22:36:52',NULL,NULL),
	(338,NULL,'Celtic',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2016-06-15 20:33:42',NULL,NULL);

/*!40000 ALTER TABLE `teams` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
